
public class Ordinateur {

    // Créer propriété privée marque
    // Créer propriété privée modele
    // Créer propriété privée nbPoucesEcran
    // Créer propriété privée prix

    // Créer constructeur

    // Créer getter marque
    // Créer setter marque

    // Créer getter modele
    // Créer setter modele

    // Créer getter nbPoucesEcran
    // Créer setter nbPoucesEcran

    // Créer getter prix
    // Créer setter prix

    // Créer toString

}
