package exoFacture;

public class Client {
	
	private String nom; 
	
	
	public Client() {
		super();
		// TODO Auto-generated constructor stub
	}
	

	public Client(String nom) {
		super();
		this.nom = nom;
	}


	public String getNom() {
		return nom;
	}

	public void setNom(String nom) {
		this.nom = nom;
	}

	
}
