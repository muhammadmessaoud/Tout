package exoFacture;

public class Fournisseur {

	private String nom;
	
	public Fournisseur() {
		super();
		// TODO Auto-generated constructor stub
	}

	
	public Fournisseur(String nom) {
		super();
		this.nom = nom;
	}


	public String getNom() {
		return nom;
	}

	public void setNom(String nom) {
		this.nom = nom;
	} 
	
}
